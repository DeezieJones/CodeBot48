- 👋 Hi, I’m @DeezieJones
- 👀 I’m interested in ...tech
- 🌱 I’m currently learning ... linux and github of course
- 💞️ I’m looking to collaborate on ...devops engineering
- 📫 How to reach me ... gmail
- 😄 Pronouns: ... bru 
- ⚡ Fun fact: ...i learn very quickly

<!---
DeezieJones/DeezieJones is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
